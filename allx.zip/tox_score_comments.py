import os, sys, json, argparse, re, statistics
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

# Bot detection heuristics
BOT_TAILS = ("[bot]", "-bot", "_bot")
BOT_NAME_PAT = re.compile(
    r"(bot$|^bot-|/bot$|dependabot|renovate|mergify|snyk|codecov|pre-commit|semantic-?release|"
    r"release-please|allcontributors|sonar|readthedocs|gha-?user|github-actions|action|automerge|"
    r"appveyor|travis|circleci|bors|bors-?)", re.I)

def looks_bot_login(login: Optional[str]) -> bool:
    if not login: return False
    l = login.lower()
    if BOT_NAME_PAT.search(l): return True
    if any(l.endswith(t) for t in BOT_TAILS): return True
    return False

# Toxicity label parsing (handle negations like "not_toxic")
NEGATIONS = {"not","non","no","none","neutral","benign","safe","clean","in"}
ROOTS = ["toxic","offens","abuse","insult","obscen","hate"]

def looks_toxic_label(label: str) -> bool:
    s = label.lower().replace("-", "_").replace("/", "_")
    toks = [t for t in re.split(r"[^a-z]+", s) if t]
    st = set(toks)
    if (st & NEGATIONS) and any(any(tok.startswith(r) for tok in st) for r in ROOTS):
        return False
    return any(any(tok.startswith(r) for tok in st) for r in ROOTS)

def pick_toxic_score(outputs) -> Tuple[float, str]:
    """Extract highest toxicity score and label from model's top_k output"""
    best_score, best_label = 0.0, ""
    for d in outputs:
        label = d.get("label",""); score = float(d.get("score",0.0))
        if looks_toxic_label(label) and score > best_score:
            best_score, best_label = score, label
    if best_label == "" and outputs:
        m = max(outputs, key=lambda x: x["score"])
        best_score, best_label = float(m["score"]), m["label"]
    return best_score, best_label

class ToxicScorer:
    """Wrapper for HuggingFace toxicity classifier with batching"""
    def __init__(self, model_name: str, batch_size: int, threshold: float, device: Optional[str]):
        self.model_name = model_name
        self.batch = int(batch_size)
        self.th = float(threshold)
        self.device = device
        self.pipe = None

    def load(self):
        """Lazy-load model on first use"""
        if self.pipe: return
        from transformers import AutoTokenizer, AutoModelForSequenceClassification, TextClassificationPipeline
        import torch
        tok   = AutoTokenizer.from_pretrained(self.model_name)
        model = AutoModelForSequenceClassification.from_pretrained(self.model_name)
        device_arg = -1
        if self.device:
            if self.device == "cuda" and torch.cuda.is_available():
                device_arg = 0
            elif self.device == "mps" and torch.backends.mps.is_available():
                model.to("mps"); device_arg = torch.device("mps")
            else:
                device_arg = -1
        self.pipe = TextClassificationPipeline(model=model, tokenizer=tok, device=device_arg)

    def score_texts(self, texts: List[str]) -> Tuple[List[int], List[float], List[str]]:
        """Batch-score texts; returns (binary_labels, scores, top_labels)"""
        self.load()
        labels, scores, top_labels = [], [], []
        for i in range(0, len(texts), self.batch):
            batch = texts[i:i+self.batch]
            outs = self.pipe(batch, truncation=True, padding=True, max_length=512, top_k=None)
            for out in outs:
                s, lbl = pick_toxic_score(out)
                scores.append(float(s))
                top_labels.append(lbl)
                labels.append(1 if s >= self.th else 0)
        return labels, scores, top_labels

# I/O helpers
def read_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def write_json(path: str, obj: Any):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def score_pr_file(pr_json_path: str, scorer: ToxicScorer, include_bots: bool) -> Dict[str, Any]:
    """Score all comments in a single PR; output includes metadata but not original text"""
    data = read_json(pr_json_path)
    comments = data.get("comments", [])
    texts, meta = [], []
    for c in comments:
        user = (c.get("user") or {})
        login = user.get("login","")
        if not include_bots and looks_bot_login(login):
            continue
        body = (c.get("body") or "").strip()
        if not body:
            continue
        texts.append(body)
        meta.append({
            "id": c.get("id"),
            "type": c.get("type"),
            "created_at": c.get("created_at"),
            "author_association": c.get("author_association"),
            "user_login": login
        })

    if not texts:
        out = {
            "repo": data.get("repo"),
            "shard_id": data.get("shard_id"),
            "pr_number": data.get("pr_number"),
            "asof": data.get("asof"),
            "window": data.get("window"),
            "counts": {"scored": 0, "toxic": 0},
            "scores": []
        }
        return out

    y, s, lbls = scorer.score_texts(texts)
    toxic = int(sum(y))
    scores = []
    for m, yi, si, li in zip(meta, y, s, lbls):
        scores.append({
            "id": m["id"],
            "type": m["type"],
            "created_at": m["created_at"],
            "author_association": m["author_association"],
            "user_login": m["user_login"],
            "toxic": int(yi),
            "score": float(si),
            "top_label": li
        })
    out = {
        "repo": data.get("repo"),
        "shard_id": data.get("shard_id"),
        "pr_number": data.get("pr_number"),
        "asof": data.get("asof"),
        "window": data.get("window"),
        "counts": {"scored": len(scores), "toxic": toxic},
        "scores": scores
    }
    return out

def aggregate_repo(repo_dir: str) -> Dict[str, Any]:
    """Aggregate per-PR tox scores into repo-level summary (count, ratio, median)"""
    pr_tox_files = [f for f in os.listdir(repo_dir) if f.startswith("pr_") and f.endswith(".tox.json")]
    total, toxic, all_scores = 0, 0, []
    for fn in pr_tox_files:
        rec = read_json(os.path.join(repo_dir, fn))
        cnt = (rec.get("counts") or {}).get("scored", 0)
        txc = (rec.get("counts") or {}).get("toxic", 0)
        total += cnt
        toxic += txc
        for srec in rec.get("scores", []):
            all_scores.append(float(srec.get("score", 0.0)))
    ratio = round(toxic / max(1, total), 4) if total else None
    med = float(statistics.median(all_scores)) if all_scores else None

    idx = read_json(os.path.join(repo_dir, "index.json"))
    out = {
        "repo": idx.get("repo"),
        "shard_id": idx.get("shard_id"),
        "asof": idx.get("asof"),
        "pr_count_dumped": idx.get("pr_count_dumped"),
        "comment_counts": idx.get("counts"),
        "tox_scored_comments": total,
        "tox_toxic_comments": toxic,
        "tox_ratio": ratio,
        "tox_median_score": med,
        "pr_tox_files": sorted(pr_tox_files)
    }
    return out

def append_shard_tox_manifest(dump_root: str, shard_id: str, repo_rel_index: str):
    """Append repo's tox_index.json path to shard-level manifest"""
    path = os.path.join(dump_root, f"{shard_id}.tox.index.json")
    arr = []
    if os.path.exists(path):
        try: arr = read_json(path)
        except Exception: arr = []
    arr.append({"index": repo_rel_index})
    write_json(path, arr)

def main():
    ap = argparse.ArgumentParser(description="Toxicity scoring over dumped PR comments (JSON only)")
    ap.add_argument("--dump_root", required=True, help="root dir with dumped comments (e.g., mined/comments_365d)")
    ap.add_argument("--shard_id", required=True, help="shard to score (e.g., shard_01)")
    ap.add_argument("--model", default="SkolkovoInstitute/roberta_toxicity_classifier")
    ap.add_argument("--threshold", type=float, default=0.5)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--device", choices=["cpu","cuda","mps"], default="cpu")
    ap.add_argument("--include_bots", action="store_true", help="score bot comments too (default: skip)")
    ap.add_argument("--max_workers", type=int, default=4)
    args = ap.parse_args()

    shard_dir = os.path.join(args.dump_root, args.shard_id)
    if not os.path.isdir(shard_dir):
        print(f"Shard dir missing: {shard_dir}", file=sys.stderr)
        sys.exit(2)

    scorer = ToxicScorer(args.model, args.batch, args.threshold, None if args.device=="cpu" else args.device)

    repos = [d for d in os.listdir(shard_dir) if os.path.isdir(os.path.join(shard_dir, d))]
    for repo_dir_name in repos:
        repo_dir = os.path.join(shard_dir, repo_dir_name)
        idx_path = os.path.join(repo_dir, "index.json")
        if not os.path.exists(idx_path):
            continue

        # Per-PR scoring (parallelized, idempotent)
        pr_files = [f for f in os.listdir(repo_dir) if f.startswith("pr_") and f.endswith(".comments.json")]
        work = []
        with ThreadPoolExecutor(max_workers=args.max_workers) as ex:
            futures = {}
            for fn in pr_files:
                src = os.path.join(repo_dir, fn)
                dst = os.path.join(repo_dir, fn.replace(".comments.json", ".tox.json"))
                if os.path.exists(dst):
                    continue
                futures[ex.submit(score_pr_file, src, scorer, args.include_bots)] = (src, dst)
            for fut in as_completed(futures):
                src, dst = futures[fut]
                try:
                    out = fut.result()
                    write_json(dst, out)
                except Exception as e:
                    print(f"[warn] failed scoring {src}: {e}", file=sys.stderr)

        # Repo-level aggregation
        rep_out = aggregate_repo(repo_dir)
        tox_index_path = os.path.join(repo_dir, "tox_index.json")
        write_json(tox_index_path, rep_out)

        # Update shard manifest
        repo_rel_idx = os.path.join(args.shard_id, repo_dir_name, "tox_index.json")
        append_shard_tox_manifest(args.dump_root, args.shard_id, repo_rel_idx)

        print(json.dumps({
            "repo": rep_out.get("repo"),
            "tox_ratio": rep_out.get("tox_ratio"),
            "tox_scored_comments": rep_out.get("tox_scored_comments"),
            "tox_median_score": rep_out.get("tox_median_score")
        }, ensure_ascii=False))

if __name__ == "__main__":
    main()

